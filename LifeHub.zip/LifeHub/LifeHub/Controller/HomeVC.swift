//
//  HomeVC.swift
//  LifeHub
//
//  Created by Jenish Shah on 2025-06-02.
//

/// HomeVC
class HomeVC: ParentVC {
    
    /// View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepareUI()
    }
}

// MARK: - UI Related Method(s)
extension HomeVC {

    func prepareUI() {
        
    }
}
